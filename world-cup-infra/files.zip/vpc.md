# VPC — Virtual Private Cloud

## What it does

A VPC is a logically isolated network inside AWS. Everything you create (EC2 instances, EKS nodes, RDS) lives inside a VPC. You control the IP address range, subnet layout, routing, and what can communicate with what.

Without a VPC there is no networking. It is the foundation every other service builds on.

## Key concepts

**CIDR block** — the IP range for the entire VPC. `10.0.0.0/16` gives you 65,536 addresses. All subnets must be subsets of this range.

**Subnet** — a slice of the VPC CIDR in a single Availability Zone. A subnet is either public (has a route to the internet via an Internet Gateway) or private (no direct internet route). Resources in private subnets cannot be reached from the internet and cannot reach it unless you add a NAT Gateway or VPC endpoint.

**Internet Gateway (IGW)** — attached to the VPC, allows traffic between public subnets and the internet. One per VPC.

**Route table** — a set of rules that determine where traffic goes. Each subnet is associated with exactly one route table. A public subnet's route table has a rule: `0.0.0.0/0 → igw-xxxxxxxx`. A private subnet's route table has no such rule.

**Security group** — a stateful firewall attached to a resource (EC2 instance, RDS instance, EKS node). Controls inbound and outbound traffic by port, protocol, and source/destination. Think of it as a per-resource firewall, not a subnet firewall.

**VPC Flow Logs** — captures metadata (not content) about traffic flowing through the VPC. Useful for debugging connectivity issues. Writes to CloudWatch Logs or S3.

**NACL (Network ACL)** — subnet-level stateless firewall. Less commonly used than security groups for application-level control. You will use the default (allow all) for learning.

## Architecture in this project

Two VPCs:

| VPC | CIDR | Purpose |
|---|---|---|
| worldscore-eks-vpc | 10.0.0.0/16 | EKS cluster, application pods |
| worldscore-rds-vpc | 10.1.0.0/16 | PostgreSQL RDS only |

CIDRs must not overlap — overlapping CIDRs cannot be peered.

EKS VPC subnets:

| Subnet | CIDR | AZ | Type | Contains |
|---|---|---|---|---|
| public-az-a | 10.0.1.0/24 | us-east-1a | Public | Load balancer |
| public-az-b | 10.0.2.0/24 | us-east-1b | Public | Load balancer |
| private-az-a | 10.0.3.0/24 | us-east-1a | Private | EKS nodes |
| private-az-b | 10.0.4.0/24 | us-east-1b | Private | EKS nodes |

RDS VPC subnets:

| Subnet | CIDR | AZ | Type |
|---|---|---|---|
| private-az-a | 10.1.1.0/24 | us-east-1a | Private |
| private-az-b | 10.1.2.0/24 | us-east-1b | Private |

## Why EKS nodes are in private subnets

Nodes in private subnets have no public IP. They cannot be directly reached from the internet. This is standard production practice — you expose only the load balancer publicly, not the underlying compute.

## Why no NAT Gateway

NAT Gateways cost ~$32/month. Instead, EKS nodes reach AWS APIs (ECR for image pulls, Secrets Manager) via VPC Interface Endpoints, which route over the AWS private network. This is cheaper and actually more secure because the traffic never leaves AWS.

## Terraform resources involved

- `aws_vpc`
- `aws_subnet`
- `aws_internet_gateway`
- `aws_route_table`, `aws_route_table_association`, `aws_route`
- `aws_flow_log`, `aws_cloudwatch_log_group`

Community module: `terraform-aws-modules/vpc/aws` — wraps all of the above.

## CLI commands

```bash
# List all VPCs in your account
aws ec2 describe-vpcs --profile worldscore \
  --query "Vpcs[].{Id:VpcId,CIDR:CidrBlock,Name:Tags[?Key=='Name']|[0].Value}"

# List subnets in a specific VPC
aws ec2 describe-subnets --filters "Name=vpc-id,Values=<vpc-id>" \
  --profile worldscore \
  --query "Subnets[].{Name:Tags[?Key=='Name']|[0].Value,CIDR:CidrBlock,AZ:AvailabilityZone,Public:MapPublicIpOnLaunch}"

# Show route tables for a VPC
aws ec2 describe-route-tables --filters "Name=vpc-id,Values=<vpc-id>" \
  --profile worldscore \
  --query "RouteTables[].{Id:RouteTableId,Routes:Routes[].{Dest:DestinationCidrBlock,Target:GatewayId}}"

# Describe security groups in a VPC
aws ec2 describe-security-groups --filters "Name=vpc-id,Values=<vpc-id>" \
  --profile worldscore \
  --query "SecurityGroups[].{Name:GroupName,Id:GroupId}"

# View flow logs for a VPC
aws ec2 describe-flow-logs --filter "Name=resource-id,Values=<vpc-id>" \
  --profile worldscore

# Check internet gateway attached to VPC
aws ec2 describe-internet-gateways \
  --filters "Name=attachment.vpc-id,Values=<vpc-id>" \
  --profile worldscore
```

## Debugging connectivity

If a pod cannot reach RDS, check these in order:

1. VPC peering connection is `active`
2. Route tables in both VPCs have routes pointing each other's CIDR at the peering connection
3. Security group on RDS allows inbound 5432 from the EKS node group security group
4. Security group on EKS nodes allows outbound 5432 (or `0.0.0.0/0` outbound — AWS default)
5. No NACL blocking (default NACL allows all)

```bash
# Test from inside the cluster using a debug pod
kubectl run nettest --image=nicolaka/netshoot --rm -it --restart=Never \
  -- nc -zv <rds-endpoint> 5432
```

Output `Connection to <host> 5432 port [tcp/postgresql] succeeded!` means the network path is clear.

## Official docs

- [VPC overview](https://docs.aws.amazon.com/vpc/latest/userguide/what-is-amazon-vpc.html)
- [Subnets](https://docs.aws.amazon.com/vpc/latest/userguide/configure-subnets.html)
- [Route tables](https://docs.aws.amazon.com/vpc/latest/userguide/VPC_Route_Tables.html)
- [Security groups](https://docs.aws.amazon.com/vpc/latest/userguide/security-groups.html)
- [VPC peering](https://docs.aws.amazon.com/vpc/latest/peering/what-is-vpc-peering.html)
- [VPC Flow Logs](https://docs.aws.amazon.com/vpc/latest/userguide/flow-logs.html)
- [VPC endpoints](https://docs.aws.amazon.com/vpc/latest/privatelink/vpc-endpoints.html)
