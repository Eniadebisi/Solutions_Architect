# worldscore-infra

Infrastructure-as-Code for the WorldScore project. Lives inside `Solutions_Architect/worldscore-infra/`.

## Repo layout

```
Solutions_Architect/
└── worldscore-infra/
    ├── README.md               ← this file
    ├── GUIDE.md                ← step-by-step build guide (start here)
    ├── docs/
    │   ├── vpc.md
    │   ├── eks.md
    │   ├── rds.md
    │   ├── secrets-manager.md
    │   ├── external-secrets-operator.md
    │   ├── argocd.md
    │   └── github-actions.md
    ├── terraform/
    │   ├── vpc/
    │   │   ├── main.tf
    │   │   ├── variables.tf
    │   │   └── outputs.tf
    │   ├── eks/
    │   │   ├── main.tf
    │   │   ├── variables.tf
    │   │   └── outputs.tf
    │   ├── rds/
    │   │   ├── main.tf
    │   │   ├── variables.tf
    │   │   └── outputs.tf
    │   ├── peering/
    │   │   ├── main.tf
    │   │   ├── variables.tf
    │   │   └── outputs.tf
    │   ├── secrets/
    │   │   ├── main.tf
    │   │   ├── variables.tf
    │   │   └── outputs.tf
    │   └── backend.tf          ← S3 state + DynamoDB lock (shared)
    └── helm/
        └── worldscore/
            ├── Chart.yaml
            ├── values.yaml
            └── templates/
                ├── deployment.yaml
                ├── service.yaml
                ├── cronjob.yaml
                └── externalsecret.yaml
```

## Where to start

Read `GUIDE.md`. It walks you through provisioning one resource at a time with a verification step after each.

## Separation of concerns

This repo only contains infrastructure. The application code lives in `worldscore-app`. The one coupling point is the Docker image tag: when the app pipeline pushes a new image to ECR, it opens a PR here updating `helm/worldscore/values.yaml` with the new SHA tag. ArgoCD detects the merge and syncs the cluster.

## Cost estimate

| Resource | Type | Est. monthly |
|---|---|---|
| EKS cluster | Control plane only | ~$72 |
| EC2 nodes | 2× t3.small spot | ~$8 |
| RDS | db.t3.micro single-AZ | ~$15 |
| ECR | < 1GB storage | ~$0.10 |
| VPC peering | Data transfer | ~$1 |
| Secrets Manager | 2 secrets | ~$0.80 |
| **Total** | | **~$97/month** |

Tear down EKS node group when not actively developing to cut costs to ~$15/month (RDS + control plane minimum).
