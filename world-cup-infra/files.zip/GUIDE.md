# GUIDE — Building worldscore-infra step by step

Work through this in order. Each section provisions one resource, explains what you are building and why, and ends with a verification you can run before moving on. Do not move to the next section until the verification passes.

---

## Prerequisites

Before writing any Terraform, make sure the following are installed and configured locally:

- AWS CLI v2 — configured with a named profile (e.g. `worldscore`)
- Terraform >= 1.10
- kubectl
- helm >= 3
- An AWS account with sufficient IAM permissions (or an IAM user/role you will use)
- A GitHub repo for `worldscore-infra` already created (can be inside `Solutions_Architect`)

Confirm your AWS identity before starting anything:

```bash
aws sts get-caller-identity --profile worldscore
```

You should see your account ID and user/role ARN. If this fails, fix your AWS CLI config before proceeding.

---

## Step 1 — Terraform remote state backend

### What you are building

By default Terraform stores state locally in a `terraform.tfstate` file. That is fine for solo learning but breaks the moment you run from two machines or have a CI pipeline. You will create an S3 bucket and a DynamoDB table. S3 stores the state file. DynamoDB provides a lock so two `terraform apply` runs cannot corrupt it simultaneously.

### Why before everything else

Every subsequent Terraform module references this backend. If you build it last you will have to migrate state, which is harder than getting it right first.

### What to create

In `terraform/backend.tf` (shared across all modules via a `backend "s3"` block):

- S3 bucket: `worldscore-tfstate-<your-account-id>` — versioning enabled, server-side encryption enabled, public access blocked
- DynamoDB table: `worldscore-tf-lock` — partition key `LockID` (String), pay-per-request billing

Create the S3 bucket and DynamoDB table manually the first time (chicken-and-egg problem: you cannot use Terraform to create the backend that Terraform needs to store its own state). Use the AWS CLI or console.

See [`docs/terraform-backend.md`](docs/terraform-backend.md) for commands and concepts.

### Verification

```bash
aws s3 ls s3://worldscore-tfstate-<account-id> --profile worldscore
aws dynamodb describe-table --table-name worldscore-tf-lock --profile worldscore
```

Both commands should return without error. The bucket should be empty. The table should show `ACTIVE` status.

---

## Step 2 — EKS VPC

### What you are building

A Virtual Private Cloud with:
- 2 public subnets (one per AZ) — for the load balancer
- 2 private subnets (one per AZ) — for EKS nodes (nodes never have public IPs)
- An Internet Gateway attached to the VPC
- Route tables: public subnets route `0.0.0.0/0` to the IGW; private subnets have no default route to the internet (no NAT Gateway — budget choice)
- VPC Flow Logs — sends network traffic metadata to CloudWatch for debugging

CIDR: `10.0.0.0/16`

### Why no NAT Gateway

NAT Gateways cost ~$32/month plus data transfer. EKS nodes in private subnets use a VPC endpoint for ECR and Secrets Manager instead. This is a deliberate budget trade-off documented in `.trivyignore` so scanners do not flag it as a misconfiguration.

### What to create

Terraform module in `terraform/vpc/`. Use the `terraform-aws-modules/vpc/aws` community module — it is well-tested and saves writing 200 lines of subnet/route table boilerplate.

Key inputs you will set:
- `cidr = "10.0.0.0/16"`
- `azs` — two AZs in your region
- `private_subnets`, `public_subnets`
- `enable_nat_gateway = false`
- Tags on subnets: `kubernetes.io/cluster/worldscore = shared`, `kubernetes.io/role/elb = 1` (public), `kubernetes.io/role/internal-elb = 1` (private) — EKS and the ALB controller use these tags to discover subnets automatically

See [`docs/vpc.md`](docs/vpc.md) for full explanation and CLI reference.

### Verification

```bash
cd terraform/vpc
terraform init
terraform plan   # review — should show ~20 resources
terraform apply
```

After apply:

```bash
aws ec2 describe-vpcs --filters "Name=tag:Name,Values=worldscore-eks-vpc" \
  --query "Vpcs[].VpcId" --profile worldscore

aws ec2 describe-subnets --filters "Name=vpc-id,Values=<vpc-id>" \
  --query "Subnets[].{Name:Tags[?Key=='Name']|[0].Value,CIDR:CidrBlock,AZ:AvailabilityZone}" \
  --profile worldscore
```

You should see 4 subnets (2 public, 2 private) across 2 AZs.

---

## Step 3 — RDS VPC

### What you are building

A second VPC, completely separate from the EKS VPC, containing only the database. Separate VPCs are more secure than a single VPC because security groups alone cannot prevent lateral movement — a separate VPC with explicit peering is a stronger boundary.

CIDR: `10.1.0.0/16` (must not overlap with the EKS VPC)

Contents:
- 2 private subnets (one per AZ) — RDS requires a subnet group spanning at least 2 AZs even for single-AZ deployments
- No public subnets, no IGW, no route to the internet — the database has zero external network access
- A DB subnet group referencing both private subnets

### What to create

Terraform module in `terraform/rds-vpc/`. You can use the same VPC community module with `public_subnets = []` and `enable_nat_gateway = false`.

### Verification

```bash
aws ec2 describe-vpcs --filters "Name=tag:Name,Values=worldscore-rds-vpc" \
  --query "Vpcs[].{Id:VpcId,CIDR:CidrBlock}" --profile worldscore

aws rds describe-db-subnet-groups --query \
  "DBSubnetGroups[?DBSubnetGroupName=='worldscore-rds-subnet-group'].SubnetIds" \
  --profile worldscore
```

---

## Step 4 — VPC peering

### What you are building

A peering connection that allows network traffic to flow from the EKS VPC to the RDS VPC on port 5432. This is not a full mesh — only the specific port and direction you define in security groups will actually work. VPC peering alone does not open any ports.

Three things must all be in place for traffic to flow:
1. The peering connection (accepted)
2. Route table entries in both VPCs pointing each other's CIDR at the peering connection
3. Security group rules allowing the specific port

### What to create

Terraform module in `terraform/peering/`. It takes the two VPC IDs and subnet CIDRs as inputs (from the outputs of the vpc modules).

Resources:
- `aws_vpc_peering_connection` — created in the EKS VPC
- `aws_vpc_peering_connection_accepter` — accepts it (same account, so automatic)
- `aws_route` — one in each private route table of the EKS VPC pointing `10.1.0.0/16` to the peering connection
- `aws_route` — one in each private route table of the RDS VPC pointing `10.0.0.0/16` to the peering connection

### Verification

```bash
aws ec2 describe-vpc-peering-connections \
  --filters "Name=status-code,Values=active" \
  --query "VpcPeeringConnections[].{Id:VpcPeeringConnectionId,Status:Status.Code}" \
  --profile worldscore
```

Status should be `active`. Also verify routes:

```bash
aws ec2 describe-route-tables \
  --filters "Name=vpc-id,Values=<eks-vpc-id>" \
  --query "RouteTables[].Routes[?DestinationCidrBlock=='10.1.0.0/16']" \
  --profile worldscore
```

---

## Step 5 — EKS cluster

### What you are building

The Kubernetes control plane and one managed node group. EKS manages the control plane (API server, etcd, scheduler) — you only manage the node group.

Node group:
- 2 `t3.small` nodes minimum (can scale to 4)
- Placed in private subnets only
- Uses a launch template so you control the AMI and disk size
- SPOT instances for cost savings in non-prod

IAM:
- EKS cluster role — allows the control plane to call AWS APIs
- Node group role — allows nodes to pull from ECR, write to CloudWatch Logs, join the cluster
- OIDC provider — enables IRSA (IAM Roles for Service Accounts), which lets pods assume IAM roles without storing credentials

IRSA is the mechanism that lets your ESO pod call Secrets Manager without an access key. It works by annotating the Kubernetes service account with an IAM role ARN. EKS issues a short-lived token; AWS STS validates it against the OIDC provider.

### What to create

Terraform module in `terraform/eks/`. Use the `terraform-aws-modules/eks/aws` community module.

Key inputs:
- `cluster_name = "worldscore"`
- `cluster_version = "1.31"` (check latest stable at time of building)
- `vpc_id` and `subnet_ids` from VPC outputs
- `enable_irsa = true`
- Managed node group with instance type, min/max/desired counts

### Verification

```bash
aws eks update-kubeconfig --name worldscore --region us-east-1 --profile worldscore
kubectl get nodes
```

You should see 2 nodes in `Ready` state. Also:

```bash
kubectl get namespaces
aws eks describe-cluster --name worldscore \
  --query "cluster.identity.oidc.issuer" --profile worldscore
```

The OIDC issuer URL confirms IRSA is available.

---

## Step 6 — RDS instance

### What you are building

A PostgreSQL 16 RDS instance in the RDS VPC private subnets.

Configuration:
- `db.t3.micro` — Free Tier eligible
- Single-AZ (no Multi-AZ for cost — this is non-prod)
- Automated backups enabled (7-day retention)
- Deletion protection disabled (easier to tear down when learning)
- Storage: 20GB gp3, no autoscaling
- Parameter group: default postgres16
- Security group: inbound port 5432 from EKS node group security group CIDR only — nothing else

The master password is generated by Terraform using `random_password` and immediately stored in Secrets Manager. The RDS instance references the Secrets Manager secret for its master password using the `manage_master_user_password` feature (AWS manages rotation automatically).

### What to create

Terraform module in `terraform/rds/`. Use the `terraform-aws-modules/rds/aws` community module.

Key inputs:
- `engine = "postgres"`, `engine_version = "16"`
- `instance_class = "db.t3.micro"`
- `db_subnet_group_name` from RDS VPC outputs
- `vpc_security_group_ids` — RDS security group you create in this module
- `manage_master_user_password = true` — AWS stores credentials in Secrets Manager automatically

### Verification

```bash
aws rds describe-db-instances \
  --query "DBInstances[?DBInstanceIdentifier=='worldscore'].{Status:DBInstanceStatus,Endpoint:Endpoint.Address}" \
  --profile worldscore
```

Status should be `available`. Note the endpoint — you will need it when configuring ESO.

Test connectivity from inside the cluster (port-forward or a debug pod):

```bash
kubectl run pg-test --image=postgres:16 --rm -it --restart=Never \
  -- psql -h <rds-endpoint> -U worldscore -d worldscore
```

If the VPC peering and security groups are correct, this should prompt for a password and connect.

---

## Step 7 — Secrets Manager entries

### What you are building

Two secrets:

1. `worldscore/db` — created automatically by RDS in step 6 if you used `manage_master_user_password`. Contains `host`, `port`, `username`, `password`, `dbname`.
2. `worldscore/football-api` — create manually or via Terraform. Contains `FOOTBALL_API_KEY` and `FOOTBALL_API_URL`.

You also create an IAM policy that allows `secretsmanager:GetSecretValue` on both secret ARNs, and attach it to the IAM role that ESO will assume via IRSA.

### What to create

Terraform module in `terraform/secrets/`:
- `aws_secretsmanager_secret` for the football API credentials (the DB secret already exists from step 6)
- `aws_secretsmanager_secret_version` to set the initial values
- `aws_iam_policy` with `GetSecretValue` on both secret ARNs
- `aws_iam_role` for ESO to assume — trust policy referencing the OIDC provider from the EKS cluster

### Verification

```bash
aws secretsmanager get-secret-value \
  --secret-id worldscore/db \
  --query SecretString --profile worldscore

aws secretsmanager get-secret-value \
  --secret-id worldscore/football-api \
  --query SecretString --profile worldscore
```

Both should return JSON with the expected keys. Do not commit these values anywhere.

---

## Step 8 — Install ArgoCD

### What you are building

ArgoCD is the GitOps controller. It watches the `worldscore-infra` repo and reconciles the cluster state to match what is in Git. You install it into the cluster via Helm.

ArgoCD runs in its own namespace (`argocd`). It has a UI (accessible via port-forward), a CLI (`argocd`), and an API server. The `Application` CRD is how you tell it what repo to watch and what Helm chart to deploy.

### What to create

This is a `helm install` command, not Terraform. You run it once manually to bootstrap the cluster. After ArgoCD is running, everything else deploys through it.

```bash
kubectl create namespace argocd

helm repo add argo https://argoproj.github.io/argo-helm
helm repo update

helm install argocd argo/argo-cd \
  --namespace argocd \
  --set server.service.type=ClusterIP
```

Then create the ArgoCD `Application` manifest at `argocd/app.yaml` in your infra repo. This tells ArgoCD to watch `helm/worldscore/` in this repo and sync it to the `worldscore` namespace in the cluster.

See [`docs/argocd.md`](docs/argocd.md) for the full Application manifest structure and explanation.

### Verification

```bash
kubectl get pods -n argocd
kubectl port-forward svc/argocd-server -n argocd 8080:443
```

Open `https://localhost:8080` — you should see the ArgoCD UI. Get the initial admin password:

```bash
kubectl get secret argocd-initial-admin-secret -n argocd \
  -o jsonpath="{.data.password}" | base64 -d
```

---

## Step 9 — Install External Secrets Operator

### What you are building

ESO is a Kubernetes controller that bridges AWS Secrets Manager and Kubernetes `Secret` objects. Without it, you would have to manually create K8s secrets and keep them in sync with AWS. ESO watches `ExternalSecret` CRDs and automatically creates and rotates native K8s secrets.

The `ExternalSecret` manifest in your Helm chart (`templates/externalsecret.yaml`) references the IAM role ARN you created in step 7. ESO's service account is annotated with that ARN — when it calls Secrets Manager, AWS validates the IRSA token and grants access.

### What to create

Another `helm install`:

```bash
helm repo add external-secrets https://charts.external-secrets.io
helm repo update

helm install external-secrets external-secrets/external-secrets \
  --namespace external-secrets \
  --create-namespace
```

Then create a `ClusterSecretStore` manifest (or `SecretStore` per namespace) that tells ESO which AWS region to use and which service account to authenticate as.

See [`docs/external-secrets-operator.md`](docs/external-secrets-operator.md) for the SecretStore and ExternalSecret manifests.

### Verification

```bash
kubectl get pods -n external-secrets
kubectl get clustersecretstore
```

The SecretStore should show `Ready: True`. Then apply a test ExternalSecret and check:

```bash
kubectl get externalsecret -n worldscore
kubectl get secret worldscore-db-secret -n worldscore -o jsonpath="{.data.host}" | base64 -d
```

The decoded value should be your RDS endpoint.

---

## Step 10 — Deploy the app via ArgoCD

### What you are building

With all infrastructure in place, you now deploy the application by applying the ArgoCD `Application` manifest. ArgoCD reads the Helm chart from `helm/worldscore/`, renders the templates with `values.yaml`, and applies them to the cluster.

The Helm chart creates:
- `Deployment` — the worldscore-api pods
- `CronJob` — the daily fetch job
- `Service` — cluster-internal access to the API
- `ExternalSecret` — triggers ESO to create the DB credentials secret

The app pods will only start cleanly if:
- The ExternalSecret has synced (so the K8s secret exists)
- The RDS instance is reachable via VPC peering
- The ECR image exists (you must have run the app pipeline at least once)

### Steps

1. Push the `argocd/app.yaml` manifest to the infra repo
2. Apply it to the cluster: `kubectl apply -f argocd/app.yaml`
3. ArgoCD detects the Application and begins syncing

### Verification

```bash
kubectl get application -n argocd
kubectl get pods -n worldscore
kubectl logs -n worldscore -l app=worldscore-api
```

The pods should be `Running`. Logs should show the structlog JSON startup messages with no errors.

Port-forward to test end-to-end:

```bash
kubectl port-forward svc/worldscore-api 8000:8000 -n worldscore
curl http://localhost:8000/health
curl http://localhost:8000/scores/fetch
```

`/health` should return `{"status":"ok"}`. `/scores/fetch` should return scores data from the football API and confirm it was written to RDS.

---

## Step 11 — GitHub Actions pipeline

### What you are building

The CI/CD pipeline in `worldscore-app/.github/workflows/`. This runs on every push to `main` and on every PR.

Pipeline steps:
1. Lint (`ruff`)
2. Test (`pytest` with a Postgres service container)
3. SAST (Snyk code scan, SonarQube quality gate)
4. Build Docker image (tagged `${{ github.sha }}`)
5. Container scan (Snyk container)
6. Push to ECR
7. Open a PR on `worldscore-infra` updating `helm/worldscore/values.yaml` with the new image SHA

Step 7 is the handoff between the two repos. The app pipeline never touches the cluster directly — it only updates the infra repo, and ArgoCD handles the rest.

See [`docs/github-actions.md`](docs/github-actions.md) for workflow file structure, required secrets, and OIDC setup for keyless AWS authentication.

### Verification

Push a commit to `worldscore-app`. Check the Actions tab in GitHub. All jobs should pass. Check ECR for the new image:

```bash
aws ecr list-images --repository-name worldscore \
  --query "imageIds[].imageTag" --profile worldscore
```

You should see a tag matching the commit SHA. Check the infra repo for a PR updating `values.yaml`. Merge it and watch ArgoCD sync.

---

## Tear-down order

When you want to destroy the environment to save costs, work in reverse order:

1. `kubectl delete application worldscore -n argocd`
2. `helm uninstall argocd -n argocd`
3. `helm uninstall external-secrets -n external-secrets`
4. `terraform destroy` in: `terraform/rds/` → `terraform/peering/` → `terraform/eks/` → `terraform/rds-vpc/` → `terraform/vpc/`
5. Delete ECR images manually (ECR repos with images will block destroy unless `force_delete = true`)
6. Delete S3 state bucket contents manually before destroying the backend

Do not destroy the S3 backend bucket while any state files reference it.
